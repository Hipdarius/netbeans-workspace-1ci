Museum Crate Planner | Z2_MuseumCratePlanner

Extract the ZIP and open Z2_MuseumCratePlanner in Apache NetBeans with JDK 17 or newer.
Press F6 before starting the timer to confirm the demo tree opens.
Keep Part II and the source files closed until you finish modelling.

In scipr.museum.view, open MainFrame in Design to inspect the JFrame form.
Use Source for the numbered TODOs. Sample manifests are in samples/.

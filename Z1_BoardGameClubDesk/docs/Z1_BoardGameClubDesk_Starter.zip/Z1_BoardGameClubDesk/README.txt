BOARD GAME CLUB DESK
SCIPR practice test | NetBeans starter project

Run F6 before starting the timer, then close the application.
Keep Part II and the source files closed until you finish modelling.

1. Extract the entire ZIP. In NetBeans, choose File > Open Project and
   select the extracted Z1_BoardGameClubDesk folder.
2. Use Run Project (F6). The JFrame is MainFrame in the boardclub package.
   Its GUI and event handlers are supplied. Work on the TODOs identified
   in the implementation booklet. The roster, notes results and board
   markers will be incomplete until those methods are written.
3. To try Load JSON, copy example-players.json to players.json in the
   project folder. Keep the original fixture for another test. Save JSON
   writes players.json. The app loads this file when you click Load JSON.
4. For the search benchmark, open SearchLab.java and choose Run File
   (Shift+F6). ClubMath methods can be checked separately with sample calls.

The project has been configured for Java 11 or newer and uses the Gson
JAR in lib. Run from the project directory so the data files are visible.
